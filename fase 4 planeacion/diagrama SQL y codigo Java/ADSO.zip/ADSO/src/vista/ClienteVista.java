
package vista;

import javax.swing.JLabel;
import javax.swing.JTextField;


public class ClienteVista extends PersonaVista{
    public JLabel lDescuento=new JLabel("Descuento");
    public JTextField txtDescuento=new JTextField();

    public ClienteVista() {
        super();
        add(lDescuento);
        add(txtDescuento);
        
        crearBotones();
        setTitle("Cliente");             
    }
}
