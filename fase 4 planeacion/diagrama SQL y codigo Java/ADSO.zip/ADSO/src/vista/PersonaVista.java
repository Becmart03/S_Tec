/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.*;

/**
 *
 * @author becma
 */
public class PersonaVista extends JFrame{

    public JLabel lDocumento=new JLabel("Documento");
    public JLabel lNombre=new JLabel("Nombre");
    public JLabel lApellido=new JLabel("Apellido");
    public JLabel lCorreo=new JLabel("Correo");
    public JLabel lClave1=new JLabel("Clave");
    public JLabel lClave2=new JLabel("Repetir Clave");
    
    public JTextField txtDocumento=new JTextField();
    public JTextField txtNombre=new JTextField();
    public JTextField txtApellido=new JTextField();
    public JTextField txtCorreo=new JTextField();
    public JPasswordField txtClave1=new JPasswordField();
    public JPasswordField txtClave2=new JPasswordField();
    
    public JButton btnGuardar=new JButton("Guardar");
    public JButton btnReset=new JButton("Reset");
    
    public PersonaVista() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setBounds(0,0,200,400);
        
        setLayout(new GridLayout(8,2));
                
        add(lDocumento);
        add(txtDocumento);
        add(lNombre);
        add(txtNombre);
        add(lApellido);
        add(txtApellido);
        add(lCorreo);
        add(txtCorreo);
        add(lClave1);
        add(txtClave1);
        add(lClave2);
        add(txtClave2);
    }
    
    public void crearBotones(){
        add(btnReset);
        add(btnGuardar);
    }
    
}
