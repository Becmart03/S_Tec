package vista;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class EmpleadoVista extends PersonaVista {

    public JLabel lComision=new JLabel("Comision");
    public JTextField txtComision=new JTextField();

    public EmpleadoVista() {
        super();
        
        add(lComision);
        add(txtComision);
        
        
        crearBotones();
        setTitle("Empleado");
    }
    
    
    
}
 