package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Cliente;
import vista.ClienteVista;


public class ClienteControlador extends PersonaControlador implements ActionListener{
    ClienteVista vista;
    public ClienteControlador(ClienteVista vista) {
        super();
        vista.btnGuardar.addActionListener(this);
    }
    
    @Override
    public void validarEmail() {
    }

    @Override
    public void actionPerformed(ActionEvent e2) {
        Cliente e=new Cliente();
        e.setDocumento(Integer.parseInt(vista.txtDocumento.getText()));
        e.setNombre(vista.txtNombre.getText());
        e.setApellido(vista.txtApellido.getText());
        e.setEmail(vista.txtCorreo.getText());
        e.setClave(vista.txtClave1.getText());
        e.setDescuento(Double.parseDouble(vista.txtDescuento.getText()));
        String persona="insert into Personas values('"+e.getDocumento()+"','"+e.getNombre()+"','"+e.getApellido()+"','"+e.getEmail()+"','"+e.getClave()+"')";
        String cliente="insert into Cliente values('"+e.getDescuento()+"','"+e.getDocumento()+"')";
        crear(persona);
        crear(cliente);
    }
    
}
