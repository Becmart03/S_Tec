
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Cliente;
import modelo.Empleado;
import vista.EmpleadoVista;


public class EmpleadoControlador extends PersonaControlador implements ActionListener{
    
    EmpleadoVista vista;
    public EmpleadoControlador(EmpleadoVista vista){
        super();
        vista.btnGuardar.addActionListener(this);
        
    }
    public void subirComision(double valor) {
    }
    public void bajarComision(double valor) {
    }

    @Override
    public void validarEmail() {
    }

    @Override
    public void actionPerformed(ActionEvent e2) {
        
        Empleado e=new Empleado();
        e.setDocumento(Integer.parseInt(vista.txtDocumento.getText()));
        e.setNombre(vista.txtNombre.getText());
        e.setApellido(vista.txtApellido.getText());
        e.setEmail(vista.txtCorreo.getText());
        e.setClave(vista.txtClave1.getText());
        e.setComision(Double.parseDouble(vista.txtComision.getText()));
        String persona="insert into Personas values('"+e.getDocumento()+"','"+e.getNombre()+"','"+e.getApellido()+"','"+e.getEmail()+"','"+e.getClave()+"')";
        String empleado="insert into Empleados values('"+e.getComision()+"','"+e.getDocumento()+"')";
        
        
        crear(persona);
        crear(empleado);
    }


    
}
