
package controlador;

import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public abstract class PersonaControlador implements ICRUD, ActionListener{

    public void validarDocumento() {
    }

    public void validarEmail() {
    }

    public void validarClave() {
    }

    public void resetClave() {
    }
    
    @Override
    public void crear(String sql) {
        try {
            Connection c=Conexion.obtenerConexion();
            Statement stm=c.createStatement();
            stm.execute(sql);
            JOptionPane.showMessageDialog(null,"El dato se ha guardado");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"El dato no se ha guardado");
            Logger.getLogger(PersonaControlador.class.getName()).log(Level.SEVERE, null, ex);
        }     
        
    }

    @Override
    public void eliminar() {
    }

    @Override
    public void editar() {
    }

    @Override
    public void consultar() {
    }
    
}
