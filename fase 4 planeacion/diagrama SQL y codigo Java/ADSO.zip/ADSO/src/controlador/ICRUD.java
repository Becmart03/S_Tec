
package controlador;


public interface ICRUD {
    void crear(String sql);
    void eliminar();
    void editar();
    void consultar();
    
}
