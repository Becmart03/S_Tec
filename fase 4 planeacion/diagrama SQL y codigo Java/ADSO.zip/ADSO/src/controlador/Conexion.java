package controlador;

import java.sql.*;


public class Conexion {
    
    private final static String URL = "jdbc:mysql://localhost:3306/adso";
    private final static String USUARIO = "root";
    private final static String CONTRASENA = "920305_Mysql";

    static Conexion instancia;
    static Connection conexion;

    public Conexion() {
    }
    
    public static Connection obtenerConexion(){
        if (conexion == null){
            crearConexion();
        }
        return conexion;
    }
            
    private static void crearConexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
        } catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }
    
    public static void cerraConexion(){
        if (conexion != null) {
            try {
                conexion.close();
            }catch (SQLException e) {
                e.printStackTrace();
            }finally{
                conexion = null;
            }
        }   
    }
}
