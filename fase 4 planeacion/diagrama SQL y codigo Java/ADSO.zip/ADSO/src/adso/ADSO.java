
package adso;

import controlador.ClienteControlador;
import controlador.EmpleadoControlador;
import controlador.PersonaControlador;
import vista.ClienteVista;
import vista.EmpleadoVista;
import vista.PersonaVista;





public class ADSO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EmpleadoVista ev=new EmpleadoVista();
        ClienteVista cv=new ClienteVista();
        PersonaControlador ec=new EmpleadoControlador(ev);
        PersonaControlador cc=new ClienteControlador(cv);
        ev.setVisible(true);
        cv.setVisible(true);

   
    }
    
    public static void ver(PersonaVista pv){

    }
    
}
