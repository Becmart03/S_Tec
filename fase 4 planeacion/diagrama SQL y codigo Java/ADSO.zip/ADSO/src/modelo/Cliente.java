
package modelo;


public class Cliente extends Persona{
    private double descuento;

    public Cliente() {
    }
    
    


    public Cliente(double descuento) {
        this.descuento = descuento;
    }

    public Cliente(double descuento, int documento, String nombre, String apellido, String email, String clave) {
        super(documento, nombre, apellido, email, clave);
        this.descuento = descuento;
    }
    

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
    
    
}
