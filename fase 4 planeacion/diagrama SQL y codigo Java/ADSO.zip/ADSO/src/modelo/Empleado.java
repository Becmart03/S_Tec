
package modelo;


public class Empleado extends Persona {
    
    private double comision;

    public Empleado() {
    }
    
    public Empleado(double comision) {
        this.comision = comision;
    }

    public Empleado(double comision, int documento, String nombre, String apellido, String email, String clave) {
        super(documento, nombre, apellido, email, clave);
        this.comision = comision;
    }
    
   
    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }
    
}
