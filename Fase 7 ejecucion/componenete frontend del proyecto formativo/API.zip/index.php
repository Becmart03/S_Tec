<?php
$metodo = $_SERVER['REQUEST_METHOD'];

switch ($metodo){
    case 'GET':
        getUsuario($_GET['id']);
        break;
    case 'POST':
        createUsuario();
        break;
    case 'PUT':
        updateUsuario();
        break;
    case 'DELETE':
        deleteUsuario($_GET['id']);
        break;
    default:
        echo 'locochon';
    
}

function getUsuario($id){
    require_once './conexion.php';
    if($id!=""){
        $sql = "SELECT id, nombre, apellido, email FROM usuarios WHERE id=$id";
    }else{
        $sql = "SELECT id, nombre, apellido, email FROM usuarios";
    }
    $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $data = array();
            while($row = $result->fetch_assoc()) {
                  $data[] = array(
                    "id"=>$row["id"],
                    "nombre"=>$row["nombre"],
                    "apellido"=>$row["apellido"],
                    "email"=>$row["email"]
          );
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        } 
        else {
          echo "0 results";
        }
        $conn->close();
}

function createUsuario(){
    require_once './conexion.php';
    
    $json = file_get_contents("php://input");
    $datos = json_decode($json,true);
    if(isset($datos['id']) &&
            isset($datos['nombre']) &&
            isset($datos['apellido']) &&
            isset($datos['email']) &&
            isset($datos['clave'])){
        $sql = "INSERT INTO usuarios values("
                . "'".$datos['id']."',"
                . "'".$datos['nombre']."',"
                . "'".$datos['apellido']."',"
                . "'".$datos['email']."',"
                . "SHA1('".$datos['clave']."'))";
        if($conn-> query($sql)===TRUE){
            echo "New record created";
        }else{
            echo "Error" . $sql . "<br>" . $conn->error;
        }
        
    }

    $conn->close();
    
}
function deleteUsuario($id){
    require_once './conexion.php';
    $sql="DELETE FROM usuarios WHERE id=$id";
    if ($conn->query($sql) === TRUE){
        echo "usuario eliminado";
    }else{
        echo "Error:" .$sql . "<br>" .$conn->error;
    }
    
    $conn->close();
}
function updateUsuario(){
    require_once './conexion.php';
    
    $json = file_get_contents("php://input");
    $datos = json_decode($json,true);
    if(isset($datos['id']) &&
            isset($datos['nombre']) &&
            isset($datos['apellido']) &&
            isset($datos['email']) &&
            isset($datos['clave'])){
        $sql = "UPDATE usuarios SET "
                . "nombre='" . $datos['nombre'] . "',"
                . "apellido='" . $datos['apellido'] . "',"
                . "email='" . $datos['email'] . "',"
                . "clave=SHA1('" . $datos['email'] . "')"
                . "WHERE id='". $datos['id'] . "'";
        if($conn-> query($sql)===TRUE){
            echo "New record updated";
        }else{
            echo "Error" . $sql . "<br>" . $conn->error;
        }
        
    }

    $conn->close();
    
}
?>