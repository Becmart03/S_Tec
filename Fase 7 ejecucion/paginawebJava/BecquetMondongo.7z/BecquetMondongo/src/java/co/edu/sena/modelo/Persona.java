/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.sena.modelo;

/**
 *
 * @author becquet
 */
public class Persona {
    
    public static String user=null;
    private String nombre;
    private String apellido;
    private String email;
    private String Contrasena;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasena() {
        return Contrasena;
    }

    public void setContrasena(String Contrasena) {
        this.Contrasena = Contrasena;
    }
    public String credenciales(){
        return "SELECT email FROM personas WHERE email='"+getEmail()+"' AND contrasena=md5('"+getContrasena()+"')";
    }
    public String actualizar(){
        return "UPDATE Personas set nombre='"+getNombre()+"', apellido='"+getApellido()+"', contrasena=md5('"+getContrasena()+"') WHERE email='"+getEmail()+"'";
    }
    public static String perfil(){
        return "SELECT nombre, apellido, email FROM personas WHERE email='"+user+"'";
    }
    public String eliminar(){
        String sql= "DELETE FROM personas WHERE email='"+user+"'";
        user=null;
        return sql;
    }
    
    
    
}
